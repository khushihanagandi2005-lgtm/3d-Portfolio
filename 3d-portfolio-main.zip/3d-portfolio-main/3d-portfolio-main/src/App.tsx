import { useState } from 'react'
import { About } from './components/About'
import { Contact } from './components/Contact'
import { Hero } from './components/Hero'
import { Navbar } from './components/Navbar'
import { Projects } from './components/Projects'
import { Services } from './components/Services'

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <div className="relative min-h-screen" style={{ fontFamily: 'var(--font-body)' }}>
      <Navbar menuOpen={menuOpen} setMenuOpen={setMenuOpen} />
      <Hero />
      <About />
      <Services />
      <Projects />
      <Contact />
    </div>
  )
}
