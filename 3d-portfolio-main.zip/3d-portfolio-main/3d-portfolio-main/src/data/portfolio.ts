export const profile = {
  name: 'Khushi H',
  role: 'Fullstack Developer ',
  tagline: 'Building ideas. Exploring technology. Creating possibilities.',
  bio: [
    'Motivated and growth-driven Computer Science Engineering student currently pursuing BE (4th year) with a strong academic foundation in science (PUC)',
    'Skilled in front-end development and data analytics, with hands-on experience through internship and real-time projects',
    'Proficient in HTML, CSS, JavaScript, PHP,ML,Java ,Python and MongoDB. Participated in SIH 2025 and engaged in projects focused on AI, e-commerce, and real-world problem solving',
     'Quick learner with excellent analytical,problem-solving, and teamwork skills, seeking opportunities to contribute to impactful software projects and grow in the tech industry',

 


  ],
  focus: 'AI · Development · Web · Machine Learning',
  location: 'Available worldwide',
  email: 'khushi.hanagandi2005@gmail.com',
  linkedin: 'https://www.linkedin.com/in/khushi-hanagandi-306269300/',
  github: 'https://github.com/khushihanagandi2005-lgtm',

}

export const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Work', href: '#work' },
  { label: 'Contact', href: '#contact' },
] as const

export const hero = {
  blurLine1: `Hey there, I'm ${profile.name},`,
  blurLine2: `${profile.role}, this is my portfolio`,
  typewriter:
    'Glad you stopped in. Good taste tends to find us. Now, what are we building?',
  pills: [
    { label: 'See my work', href: '#work' },
    { label: 'Build with me', href: '#services' },
    { label: 'About me', href: '#about' },
    { label: 'How I operate', href: '#services' },
  ],
}

export type TechLogo =
  | 'n8n'
  | 'html'
  | 'css'
  | 'javascript'
  | 'python'
  | 'tensorflow'
  | 'pytorch'
  | 'openai'
  | 'voice'
  | 'firebase'
  | 'linkedin'
  | 'github'
  | 'streamlit'
  | 'sklearn'
  | 'pandas'

export type Service = {
  title: string
  description: string
  logos: TechLogo[]
}

export const servicesIntro =
  'I build intelligent digital solutions that combine AI, automation, web technology, and machine learning, tailored around the needs of each project.'

export const services: Service[] = [
  {
    title: 'AI Voice Agents',
    description:
      'Conversational voice systems designed to handle natural interactions, automate communication, and create intelligent voice experiences.',
    logos: ['voice', 'openai'],
  },
  {
    title: 'AI Chatbots & Automation',
    description:
      'AI-powered chatbots built with n8n, connected to APIs, databases, and external tools to automate conversations, capture information, and streamline workflows.',
    logos: ['n8n', 'openai'],
  },
  
  {
    title: 'Web Development',
    description:
      'Modern, responsive websites and web applications with clean interfaces, thoughtful user experiences, and reliable functionality.',
    logos: ['html', 'css', 'javascript'],
  },
  {
    title: 'Machine Learning & AI',
    description:
      'Machine learning and AI solutions designed to transform data into useful insights, intelligent features, and practical real-world applications.',
    logos: ['python', 'tensorflow', 'pytorch'],
  },
]

export const contactBlurb =
  'Have an idea, a workflow that needs automating, or a problem you want to solve? Let’s turn it into a working digital solution.'

export type Project = {
  title: string
  description: string
  tags: string[]
  logos?: TechLogo[]
  liveUrl?: string
  githubUrl?: string
  docsUrl?: string
  linkedinUrl?: string
}

export const projects: Project[] = [
  {
    title: 'AI based crop recommendation system',
    description:
      'An AI-based crop recommendation system that helps farmers identify suitable crops based on agricultural and environmental conditions such as soil nutrients, temperature, humidity, rainfall, and soil pH .',
    tags: ['JavaScript', 'HTML', 'CSS', 'ML','Decision Tree'],
    logos: ['html', 'css', 'javascript'],
    
  },
  
  {
    title: 'A basic e-commerce website for products listings.',
    description:
      'A modern and user-friendly e-commerce website designed for browsing and showcasing products.',
    tags: ['JavaScript', 'HTML', 'CSS', 'Node.js'],
    logos: ['html', 'css','javascript'],
  
  },

  {
    title: 'Real-Estate Property Tracker.',
    description:
      'This dashboard allows users to browse homes for sale, filter them by price, and view them on a map. ata" and how to create a great user experience for searching through thousands of listings.',
     tags: ['React.js', 'Leaflet.js', 'Firebase'],
    logos: ['html', 'css', 'javascript'],
  
  },
]
