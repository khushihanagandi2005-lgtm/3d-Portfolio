import { projects, type Project } from '../data/portfolio'
import { useInView } from '../hooks/useInView'
import { TechIcon, techLogoLabel } from './TechIcon'

function ProjectLinks({ project }: { project: Project }) {
  return (
    <div className="mt-5 flex flex-wrap items-center gap-3">
      {project.liveUrl && (
        <a
          href={project.liveUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-full border border-black/20 bg-black/5 px-3.5 py-[0.35em] text-[12px] text-black transition-opacity hover:opacity-70 sm:text-[13px]"
        >
          Live site
        </a>
      )}
      {project.linkedinUrl && (
        <a
          href={project.linkedinUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-full border border-black/20 bg-black/5 px-3.5 py-[0.35em] text-[12px] text-black transition-opacity hover:opacity-70 sm:text-[13px]"
          title="LinkedIn post"
        >
          <TechIcon name="linkedin" className="h-[16px] w-[16px]" />
          LinkedIn
        </a>
      )}
      {project.githubUrl && (
        <a
          href={project.githubUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-full border border-black/20 bg-black/5 px-3.5 py-[0.35em] text-[12px] text-black transition-opacity hover:opacity-70 sm:text-[13px]"
          title="GitHub repository"
        >
          <TechIcon name="github" className="h-[16px] w-[16px]" />
          GitHub
        </a>
      )}
      {project.docsUrl && (
        <a
          href={project.docsUrl}
          target="_blank"
          rel="noreferrer"
          className="text-[12px] text-black underline underline-offset-2 transition-opacity hover:opacity-60 sm:text-[13px]"
        >
          Docs
        </a>
      )}
    </div>
  )
}

export function Projects() {
  const { ref, inView } = useInView<HTMLElement>()

  return (
    <section
      id="work"
      ref={ref}
      className={`relative z-[3] px-5 py-16 sm:px-8 md:px-10 md:py-24 ${
        inView ? 'reveal is-visible' : 'reveal'
      }`}
    >
      <div className="mx-auto max-w-5xl">
        <div className="glass-label mb-10 rounded-2xl px-5 py-5 sm:mb-14 sm:px-7 sm:py-6">
          <p className="mb-2 text-[12px] tracking-[0.14em] text-black/65 uppercase sm:text-[13px]">
            Work
          </p>
          <h2
            className="text-[28px] leading-tight text-black sm:text-[40px]"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            Selected projects
          </h2>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {projects.map((project, i) => (
            <article
              key={project.title}
              className="glass-panel flex flex-col rounded-2xl px-6 py-7 sm:px-8 sm:py-8"
              style={{
                transitionDelay: inView ? `${i * 90}ms` : '0ms',
              }}
            >
              <h3
                className="mb-3 text-[24px] text-black sm:text-[28px]"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                {project.title}
              </h3>
              {project.logos && project.logos.length > 0 && (
                <div className="mb-4 flex flex-wrap items-center gap-2">
                  {project.logos.map((logo) => (
                    <span
                      key={logo}
                      title={techLogoLabel[logo]}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-black/10 bg-white/55"
                    >
                      <TechIcon name={logo} />
                    </span>
                  ))}
                </div>
              )}
              <p className="flex-1 text-[14px] leading-relaxed text-black/85 sm:text-[15px]">
                {project.description}
              </p>
              {!project.logos && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="rounded-full border border-black/20 bg-black/5 px-3 py-[0.2em] text-[11px] text-black/80 sm:text-[12px]"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
              <ProjectLinks project={project} />
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
