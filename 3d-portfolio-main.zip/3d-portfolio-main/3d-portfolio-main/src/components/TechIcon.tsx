import type { TechLogo } from '../data/portfolio'

const size = 22

type Props = {
  name: TechLogo
  className?: string
}

/** Compact brand marks for service cards */
export function TechIcon({ name, className = '' }: Props) {
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    className,
    'aria-hidden': true as const,
  }

  switch (name) {
    case 'n8n':
      return (
        <svg {...common} viewBox="0 0 24 24" fill="none">
          <title>n8n</title>
          <circle cx="6" cy="12" r="3.2" fill="#EA4B71" />
          <circle cx="12" cy="6.5" r="2.6" fill="#EA4B71" />
          <circle cx="12" cy="17.5" r="2.6" fill="#EA4B71" />
          <circle cx="18" cy="12" r="3.2" fill="#EA4B71" />
          <path
            d="M9 12h6M12 9v6"
            stroke="#EA4B71"
            strokeWidth="1.6"
            strokeLinecap="round"
          />
        </svg>
      )
    case 'html':
      return (
        <svg {...common} fill="none">
          <title>HTML5</title>
          <path
            d="M4.5 2.5h15l-1.4 15.7L12 21.5l-6.1-3.3L4.5 2.5z"
            fill="#E34F26"
          />
          <path d="M12 19.8l4.9-2.65.9-10.1H12V19.8z" fill="#EF652A" />
          <path
            d="M12 8.2H8.55l.2 2.2H12v2.15H9l.35 3.55L12 16.7v2.15l-3.9-1.1-.25-2.85-.1-1.15-.45-4.75H12V8.2zm0 0h3.35l-.15 2.2H12V8.2zm0 4.35h3.15l-.1 1.05-.3 3.35L12 18.85v-2.15l1.85-.5.1-1.2H12v-2.15z"
            fill="#fff"
          />
        </svg>
      )
    case 'css':
      return (
        <svg {...common} fill="none">
          <title>CSS3</title>
          <path
            d="M4.5 2.5h15l-1.4 15.7L12 21.5l-6.1-3.3L4.5 2.5z"
            fill="#1572B6"
          />
          <path d="M12 19.8l4.9-2.65.9-10.1H12V19.8z" fill="#33A9DC" />
          <path
            d="M12 8.15H8.4l.2 2.25H12v2.15H8.85l.4 4.2L12 17.9v2.15l-4.05-1.15-.3-3.2-.15-1.6-.4-4.8H12V8.15zm0 0h3.5l-.15 2.25H12V8.15zm0 4.4h3.3l-.35 3.7L12 18.05v-2.15l1.75-.5.1-.95H12V12.55z"
            fill="#fff"
          />
        </svg>
      )
    case 'javascript':
      return (
        <svg {...common} fill="none">
          <title>JavaScript</title>
          <rect x="2.5" y="2.5" width="19" height="19" rx="2" fill="#F7DF1E" />
          <path
            d="M11.1 17.6c0 1.55-.9 2.35-2.35 2.35-1.2 0-1.95-.55-2.35-1.3l1.2-.75c.25.45.55.75 1.1.75.55 0 .9-.25.9-1.2v-5.35h1.5v5.5zm3.35 2.4c-1.4 0-2.35-.7-2.8-1.65l1.2-.7c.3.55.7.9 1.45.9.6 0 1-.3 1-.75 0-.5-.4-.7-1.1-.95l-.4-.15c-1.1-.45-1.85-1.05-1.85-2.25 0-1.2.95-2.1 2.4-2.1 1.05 0 1.8.35 2.35 1.3l-1.15.75c-.25-.4-.55-.6-1-.6-.45 0-.75.25-.75.6 0 .4.25.6.9.85l.4.15c1.3.55 2.05 1.15 2.05 2.4 0 1.4-1.1 2.2-2.7 2.2z"
            fill="#000"
          />
        </svg>
      )
    case 'python':
      return (
        <svg {...common} fill="none">
          <title>Python</title>
          <path
            d="M12.1 3c-2.7 0-2.5 1.15-2.5 1.15v1.35h2.55v.4H7.4S5 5.7 5 9.35c0 3.65 1.6 3.5 1.6 3.5h.95v-1.7s-.05-1.7 1.7-1.7h2.9s1.65.05 1.65-1.6V4.55S14.95 3 12.1 3zm-1.35 1.05a.55.55 0 110 1.1.55.55 0 010-1.1z"
            fill="#3776AB"
          />
          <path
            d="M11.9 21c2.7 0 2.5-1.15 2.5-1.15v-1.35h-2.55v-.4h4.75S21 18.3 21 14.65c0-3.65-1.6-3.5-1.6-3.5h-.95v1.7s.05 1.7-1.7 1.7h-2.9s-1.65-.05-1.65 1.6v3.2S9.05 21 11.9 21zm1.35-1.05a.55.55 0 110-1.1.55.55 0 010 1.1z"
            fill="#FFD43B"
          />
        </svg>
      )
    case 'tensorflow':
      return (
        <svg {...common} fill="none">
          <title>TensorFlow</title>
          <path
            d="M12.9 2.4l7.6 4.35v2.05l-5.35 3.05v7.55l-2.25 1.3V9.85L5.5 6.7v-2.2L12.9 2.4zm-1.8 12.2l2.15-1.25 3.4 1.95-2.15 1.25-3.4-1.95z"
            fill="#FF6F00"
          />
        </svg>
      )
    case 'pytorch':
      return (
        <svg {...common} fill="none">
          <title>PyTorch</title>
          <path
            d="M12.2 2.6c.4.4.4 1 0 1.4L9.3 6.9a5.8 5.8 0 11.8 10.2 5.8 5.8 0 007.9-2.2 5.8 5.8 0 00-2.2-7.9l.9-.9c.4-.4 1-.4 1.4 0a7.8 7.8 0 11-11 11 7.8 7.8 0 010-11l2.9-2.9c.4-.4 1-.4 1.4 0z"
            fill="#EE4C2C"
          />
          <circle cx="15.6" cy="8.2" r="1.15" fill="#EE4C2C" />
        </svg>
      )
    case 'openai':
      return (
        <svg {...common} fill="currentColor">
          <title>OpenAI</title>
          <path d="M22.28 9.66a5.95 5.95 0 00-.51-4.83 6.05 6.05 0 00-6.5-2.91 5.96 5.96 0 00-4.44-2A6.06 6.06 0 005.2 4.5a5.95 5.95 0 00-3.97 2.9 6.06 6.06 0 00.73 7.1 5.95 5.95 0 00.51 4.83 6.05 6.05 0 006.5 2.91 5.96 5.96 0 004.44 2 6.06 6.06 0 005.63-4.58 5.95 5.95 0 003.97-2.9 6.07 6.07 0 00-.73-7.1zM12.9 21.3a4.03 4.03 0 01-2.58-.92l.13-.07 4.3-2.48a.7.7 0 00.35-.6v-6.06l1.82 1.05c.04.02.07.07.07.12v4.92a4.04 4.04 0 01-4.09 4.04zm-8.74-3.73a4 4 0 01-.48-2.7l.13.08 4.3 2.48a.7.7 0 00.7 0l5.25-3.03v2.1a.14.14 0 01-.06.12l-4.35 2.51a4.04 4.04 0 01-5.49-1.56zm-1.14-9.5a4.02 4.02 0 012.1-1.85v5.1a.7.7 0 00.35.6l5.24 3.03-1.82 1.05a.15.15 0 01-.14 0l-4.35-2.51a4.04 4.04 0 01-1.38-5.42zm14.9 3.48l-5.25-3.04 1.82-1.05a.15.15 0 01.14 0l4.35 2.51a4.04 4.04 0 01-1.63 7.28v-5.1a.7.7 0 00-.35-.6h-.08zm1.8-2.72l-.13-.08-4.3-2.48a.7.7 0 00-.7 0L9.24 8.9V6.8c0-.05.02-.1.06-.12l4.35-2.51a4.04 4.04 0 015.96 4.18h-.01zM8.57 13.2l-1.82-1.05a.14.14 0 01-.07-.12V7.1a4.04 4.04 0 016.66-3.11l-.13.07-4.3 2.48a.7.7 0 00-.35.6v6.06z" />
        </svg>
      )
    case 'voice':
      return (
        <svg {...common} fill="none">
          <title>Voice</title>
          <rect x="9" y="3.5" width="6" height="10" rx="3" fill="#1D4ED8" />
          <path
            d="M6.5 11.5a5.5 5.5 0 0011 0"
            stroke="#1D4ED8"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path
            d="M12 17v3.2"
            stroke="#1D4ED8"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
          <path
            d="M9 20.5h6"
            stroke="#1D4ED8"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
        </svg>
      )
    case 'firebase':
      return (
        <svg {...common} fill="none">
          <title>Firebase</title>
          <path
            d="M5.2 17.8L8.1 3.4c.1-.5.7-.7 1.1-.3l2.5 2.4 3.2-5.9c.3-.5 1-.3 1.1.3L19 17.8 12.1 22l-6.9-4.2z"
            fill="#FFCA28"
          />
          <path d="M5.2 17.8l6.9 4.2 6.9-4.2-3.4-13.2-2.7 5-1.6-1.5-5.1 13.7z" fill="#FFA000" />
          <path d="M12.1 22l6.9-4.2-3.4-13.2L12.1 22z" fill="#F57C00" />
          <path
            d="M8.1 3.4c.1-.5.7-.7 1.1-.3l2.5 2.4-1.2 9.3L8.1 3.4z"
            fill="#FFA000"
            opacity="0.9"
          />
        </svg>
      )
    case 'linkedin':
      return (
        <svg {...common} fill="#0A66C2">
          <title>LinkedIn</title>
          <path d="M20.45 20.45h-3.55v-5.57c0-1.33-.03-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.06 2.06 0 11-.01-4.12 2.06 2.06 0 01.01 4.12zM7.12 20.45H3.56V9h3.56v11.45zM22.23 0H1.77C.79 0 0 .77 0 1.73v20.54C0 23.23.79 24 1.77 24h20.45c.98 0 1.78-.77 1.78-1.73V1.73C24 .77 23.2 0 22.23 0z" />
        </svg>
      )
    case 'github':
      return (
        <svg {...common} fill="currentColor">
          <title>GitHub</title>
          <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.009-.866-.013-1.7-2.782.604-3.369-1.341-3.369-1.341-.454-1.155-1.11-1.463-1.11-1.463-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.161 22 16.416 22 12c0-5.523-4.477-10-10-10z" />
        </svg>
      )
    case 'streamlit':
      return (
        <svg {...common} fill="none">
          <title>Streamlit</title>
          <path
            d="M13.2 4.2c.5-.9 1.8-.9 2.3 0l6.1 11.2c.5.9-.1 2-1.15 2H15.3c-.4 0-.75-.2-.95-.55L12 12.2l-2.35 4.45c-.2.35-.55.55-.95.55H3.55c-1.05 0-1.65-1.1-1.15-2L8.5 4.2c.5-.9 1.8-.9 2.3 0L12 6.85l1.2-2.65z"
            fill="#FF4B4B"
          />
        </svg>
      )
    case 'sklearn':
      return (
        <svg {...common} fill="none">
          <title>Scikit-learn</title>
          <circle cx="8.2" cy="10.5" r="4.2" fill="#F7931E" />
          <circle cx="15.8" cy="10.5" r="4.2" fill="#299D8F" />
          <circle cx="12" cy="16.2" r="3.4" fill="#8E44AD" opacity="0.9" />
        </svg>
      )
    case 'pandas':
      return (
        <svg {...common} fill="none">
          <title>Pandas</title>
          <rect x="5" y="3.5" width="3.2" height="17" rx="1" fill="#130754" />
          <rect x="15.8" y="3.5" width="3.2" height="17" rx="1" fill="#130754" />
          <rect x="9.5" y="7" width="2.2" height="5.5" rx="0.6" fill="#E70488" />
          <rect x="12.3" y="11.5" width="2.2" height="5.5" rx="0.6" fill="#E70488" />
        </svg>
      )
    default:
      return null
  }
}

export const techLogoLabel: Record<TechLogo, string> = {
  html: 'HTML5',
  css: 'CSS3',
  javascript: 'JavaScript',
  python: 'Python',
  tensorflow: 'TensorFlow',
  pytorch: 'PyTorch',
  openai: 'OpenAI',
  firebase: 'Firebase',
  linkedin: 'LinkedIn',
  github: 'GitHub',
  
  sklearn: 'Scikit-learn',
  pandas: 'Pandas',
}
