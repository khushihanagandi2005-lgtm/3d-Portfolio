import { useEffect, useRef } from 'react'

const VIDEO_SRC = '/khushi-animated.mp4'
const SENSITIVITY = 0.85
const START_TIME = 1.2
const MIN_TIME = 0.5
/** Full-res keying for a sharper, more 4K-like prtfolio-animation */
const KEY_SCALE = 1

function colorDist(
  r: number,
  g: number,
  b: number,
  sr: number,
  sg: number,
  sb: number,
) {
  const dr = r - sr
  const dg = g - sg
  const db = b - sb
  return Math.sqrt(dr * dr + dg * dg + db * db)
}

function sampleSky(data: Uint8ClampedArray, w: number, h: number) {
  let r = 0
  let g = 0
  let b = 0
  let n = 0
  for (let y = 2; y < Math.min(40, h); y += 6) {
    for (const x of [2, Math.floor(w * 0.3), Math.floor(w * 0.7), w - 3]) {
      const i = (y * w + x) * 4
      const pr = data[i]
      const pg = data[i + 1]
      const pb = data[i + 2]
      const bright = (pr + pg + pb) / 3
      if (bright > 140 && pb > pr && pb > 120) {
        r += pr
        g += pg
        b += pb
        n += 1
      }
    }
  }
  if (n < 2) return { r: 120, g: 170, b: 205 }
  return { r: r / n, g: g / n, b: b / n }
}

type Sky = { r: number; g: number; b: number }

/**
 * Single visible character layer: draw video → punch sky transparent.
 * (Hidden <video> is decode-only — stops the double-person ghost.)
 */
function paintCharacter(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
  lockedSky: Sky | null,
): Sky | null {
  if (!video.videoWidth || !video.videoHeight) return lockedSky

  const vw = video.videoWidth
  const vh = video.videoHeight
  const w = Math.max(2, Math.round(vw * KEY_SCALE))
  const h = Math.max(2, Math.round(vh * KEY_SCALE))

  if (canvas.width !== w) canvas.width = w
  if (canvas.height !== h) canvas.height = h

  const ctx = canvas.getContext('2d', { willReadFrequently: true })
  if (!ctx) return lockedSky

  ctx.clearRect(0, 0, w, h)
  ctx.drawImage(video, 0, 0, w, h)

  let frame: ImageData
  try {
    frame = ctx.getImageData(0, 0, w, h)
  } catch {
    return lockedSky
  }

  const d = frame.data
  const sky = lockedSky ?? sampleSky(d, w, h)
  let cleared = 0
  const hard = 48
  const soft = 78

  for (let i = 0; i < d.length; i += 4) {
    const r = d[i]
    const g = d[i + 1]
    const b = d[i + 2]
    const dist = colorDist(r, g, b, sky.r, sky.g, sky.b)
    const brightness = (r + g + b) / 3
    if (!(brightness > 125 && b > r - 12) || dist >= soft) continue

    if (dist < hard) {
      d[i + 3] = 0
      cleared += 1
    } else {
      d[i + 3] = Math.round(d[i + 3] * ((dist - hard) / (soft - hard)))
      cleared += 1
    }
  }

  if (cleared < w * h * 0.12 || cleared > w * h * 0.92) {
    // Keep character visible (opaque frame) rather than blanking
    ctx.drawImage(video, 0, 0, w, h)
    return lockedSky
  }

  ctx.putImageData(frame, 0, 0)
  return lockedSky ?? sky
}

export function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const video = videoRef.current
    const canvas = canvasRef.current
    if (!video || !canvas) return

    let lockedSky: Sky | null = null
    let targetTime = START_TIME
    let seeking = false
    let rafId = 0
    let pendingX: number | null = null
    let lastX: number | null = null

    const clampTime = (t: number) => {
      const max = Math.max(MIN_TIME, (video.duration || MIN_TIME) - 0.15)
      return Math.max(MIN_TIME, Math.min(t, max))
    }

    const paint = () => {
      lockedSky = paintCharacter(video, canvas, lockedSky)
    }

    const onSeeked = () => {
      seeking = false
      paint()
      if (pendingX !== null && video.duration) {
        // Apply any mouse delta queued while seeking
        const apply = pendingX
        pendingX = null
        if (lastX !== null) {
          const delta = apply - lastX
          lastX = apply
          targetTime = clampTime(
            targetTime + (delta / window.innerWidth) * SENSITIVITY * video.duration,
          )
        }
      }
      if (Math.abs(video.currentTime - targetTime) > 0.01) {
        seeking = true
        video.currentTime = targetTime
      }
    }

    const tick = () => {
      rafId = requestAnimationFrame(tick)
      if (!video.duration || Number.isNaN(video.duration)) return
      if (seeking) return
      if (Math.abs(video.currentTime - targetTime) <= 0.01) return
      seeking = true
      try {
        video.currentTime = targetTime
      } catch {
        seeking = false
      }
    }

    const onMouseMove = (e: MouseEvent) => {
      if (!video.duration || Number.isNaN(video.duration)) return
      if (lastX === null) {
        lastX = e.clientX
        return
      }
      if (seeking) {
        pendingX = e.clientX
        return
      }
      const delta = e.clientX - lastX
      lastX = e.clientX
      targetTime = clampTime(
        targetTime + (delta / window.innerWidth) * SENSITIVITY * video.duration,
      )
    }

    const onLoadedMetadata = () => {
      const start = clampTime(Math.min(START_TIME, video.duration || START_TIME))
      targetTime = start
      video.currentTime = start
    }

    video.addEventListener('seeked', onSeeked)
    video.addEventListener('loadedmetadata', onLoadedMetadata)
    video.addEventListener('loadeddata', paint)
    window.addEventListener('mousemove', onMouseMove)
    rafId = requestAnimationFrame(tick)

    if (video.readyState >= 1) onLoadedMetadata()
    if (video.readyState >= 2) paint()

    return () => {
      cancelAnimationFrame(rafId)
      video.removeEventListener('seeked', onSeeked)
      video.removeEventListener('loadedmetadata', onLoadedMetadata)
      video.removeEventListener('loadeddata', paint)
      window.removeEventListener('mousemove', onMouseMove)
    }
  }, [])

  return (
    <>
      {/* Decode-only — hidden so we never get a second ghost character */}
      <video
        ref={videoRef}
        src={VIDEO_SRC}
        muted
        playsInline
        preload="auto"
        className="pointer-events-none fixed h-px w-px opacity-0"
        aria-hidden="true"
      />

      <p className="portfolio-word" aria-hidden="true">
        P&nbsp;&nbsp;O&nbsp;&nbsp;R&nbsp;&nbsp;T&nbsp;&nbsp;F&nbsp;&nbsp;O&nbsp;&nbsp;L&nbsp;&nbsp;I&nbsp;&nbsp;O
      </p>

      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="hero-stage pointer-events-none fixed inset-0 z-[2] h-full w-full object-cover"
        style={{ objectPosition: '72% center' }}
      />

      <section id="hero" className="relative z-[3] h-screen overflow-hidden" />
    </>
  )
}
