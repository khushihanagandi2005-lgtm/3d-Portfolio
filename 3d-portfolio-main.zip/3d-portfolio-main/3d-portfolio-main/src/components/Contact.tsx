import { useState } from 'react'
import { contactBlurb, profile } from '../data/portfolio'
import { useInView } from '../hooks/useInView'
import { CopyIcon } from './CopyIcon'

function GitHubIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M12 2C6.477 2 2 6.477 2 12c0 4.42 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.009-.866-.013-1.7-2.782.604-3.369-1.341-3.369-1.341-.454-1.155-1.11-1.463-1.11-1.463-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0112 6.836c.85.004 1.705.114 2.504.336 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.161 22 16.416 22 12c0-5.523-4.477-10-10-10z" />
    </svg>
  )
}

function LinkedInIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  )
}

export function Contact() {
  const { ref, inView } = useInView<HTMLElement>()
  const [copied, setCopied] = useState(false)

  const copyEmail = () => {
    void navigator.clipboard.writeText(profile.email).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    })
  }

  return (
    <section
      id="contact"
      ref={ref}
      className={`relative z-[3] px-5 py-16 pb-28 sm:px-8 md:px-10 md:py-24 md:pb-36 ${
        inView ? 'reveal is-visible' : 'reveal'
      }`}
    >
      <div className="glass-panel mx-auto max-w-3xl rounded-3xl px-6 py-10 sm:px-10 sm:py-12">
        <p className="mb-3 text-[12px] tracking-[0.14em] text-black/55 uppercase sm:text-[13px]">
          Contact
        </p>
        <h2
          className="mb-4 text-[32px] leading-tight text-black sm:text-[42px]"
          style={{ fontFamily: 'var(--font-heading)' }}
        >
          Let&apos;s build something
        </h2>
        <p className="mb-8 max-w-xl text-[14px] leading-relaxed text-black sm:text-[15px]">
          {contactBlurb}
        </p>

        <button
          type="button"
          onClick={copyEmail}
          className="mb-8 inline-flex items-center gap-2 rounded-full border border-black/25 bg-black/5 px-5 py-[0.45em] text-[13px] text-black transition-colors duration-200 hover:bg-black hover:text-white sm:text-[14px]"
        >
          <span className="underline underline-offset-1">{profile.email}</span>
          <CopyIcon />
          <span className="text-[11px] opacity-70">{copied ? 'Copied' : 'Copy'}</span>
        </button>

        <div className="flex flex-wrap items-center gap-5">
          <a
            href={profile.github}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-[14px] text-black transition-opacity hover:opacity-60"
          >
            <GitHubIcon />
            GitHub
          </a>
          <a
            href={profile.linkedin}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-[14px] text-black transition-opacity hover:opacity-60"
          >
            <LinkedInIcon />
            LinkedIn
          </a>
        </div>
      </div>
    </section>
  )
}
