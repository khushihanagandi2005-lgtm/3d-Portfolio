import { services, servicesIntro } from '../data/portfolio'
import { useInView } from '../hooks/useInView'
import { TechIcon, techLogoLabel } from './TechIcon'

export function Services() {
  const { ref, inView } = useInView<HTMLElement>()

  return (
    <section
      id="services"
      ref={ref}
      className={`relative z-[3] px-5 py-16 sm:px-8 md:px-10 md:py-24 ${
        inView ? 'reveal is-visible' : 'reveal'
      }`}
    >
      <div className="mx-auto max-w-5xl">
        <div className="glass-label mb-10 rounded-2xl px-5 py-5 sm:mb-14 sm:px-7 sm:py-6">
          <p className="mb-2 text-[12px] tracking-[0.14em] text-black/65 uppercase sm:text-[13px]">
            Freelancing
          </p>
          <h2
            className="mb-3 text-[28px] leading-tight text-black sm:text-[40px]"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            How We Can Work Together
          </h2>
          <p className="max-w-3xl text-[14px] leading-relaxed text-black/85 sm:text-[15px]">
            {servicesIntro}
          </p>
        </div>

        <div className="flex flex-col gap-4">
          {services.map((service, i) => (
            <div
              key={service.title}
              className="glass-panel rounded-2xl px-6 py-6 sm:px-8 sm:py-7"
              style={{
                transitionDelay: inView ? `${i * 80}ms` : '0ms',
              }}
            >
              <div className="mb-3 flex flex-wrap items-center gap-3">
                <h3
                  className="text-[22px] text-black sm:text-[26px]"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {service.title}
                </h3>
                <div className="flex flex-wrap items-center gap-2">
                  {service.logos.map((logo) => (
                    <span
                      key={logo}
                      title={techLogoLabel[logo]}
                      className="inline-flex h-9 w-9 items-center justify-center rounded-xl border border-black/10 bg-white/55 text-black/85"
                    >
                      <TechIcon name={logo} />
                    </span>
                  ))}
                </div>
              </div>
              <p className="max-w-2xl text-[14px] leading-relaxed text-black/85 sm:text-[15px]">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
