import { useEffect } from 'react'
import { navLinks, profile } from '../data/portfolio'
import { LaptopLogo } from './LaptopLogo'

type NavbarProps = {
  menuOpen: boolean
  setMenuOpen: (open: boolean | ((prev: boolean) => boolean)) => void
}

export function Navbar({ menuOpen, setMenuOpen }: NavbarProps) {
  useEffect(() => {
    document.body.style.overflow = menuOpen ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [menuOpen])

  return (
    <>
      <div
        className={`fixed inset-0 z-[9] flex flex-col justify-center gap-8 bg-black/90 px-8 backdrop-blur-sm transition-opacity duration-300 md:hidden ${
          menuOpen ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
        style={{ pointerEvents: menuOpen ? 'auto' : 'none' }}
        aria-hidden={!menuOpen}
      >
        {navLinks.map((link) => (
          <a
            key={link.href}
            href={link.href}
            className="text-[28px] font-normal text-white transition-opacity hover:opacity-60"
            style={{ fontFamily: 'var(--font-logo)' }}
            onClick={() => setMenuOpen(false)}
          >
            {link.label}
          </a>
        ))}
      </div>

      <nav className="fixed top-0 z-10 flex w-full items-center justify-between gap-3 px-5 py-4 sm:px-8 sm:py-5">
        <a
          href="#hero"
          className="glass-nav flex shrink-0 items-center gap-2.5 rounded-full px-3.5 py-1.5 text-black sm:gap-3 sm:px-4 sm:py-2"
        >
          <span
            className="text-[18px] font-normal tracking-wide sm:text-[20px]"
            style={{ fontFamily: 'var(--font-logo)', fontWeight: 400 }}
          >
            {profile.name}
          </span>
          <LaptopLogo className="h-[18px] w-[18px] text-black sm:h-[20px] sm:w-[20px]" />
        </a>

        <div className="glass-nav hidden items-center gap-1 rounded-full px-2 py-1.5 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-full px-3.5 py-1.5 text-[13px] tracking-wide text-black transition-colors hover:bg-white/25"
              style={{ fontFamily: 'var(--font-body)' }}
            >
              {link.label}
            </a>
          ))}
        </div>

        <button
          type="button"
          className="glass-nav flex flex-col gap-[5px] rounded-full px-3 py-3 md:hidden"
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span
            className={`h-[2px] w-6 bg-black transition duration-300 ${
              menuOpen ? 'translate-y-[7px] rotate-45' : ''
            }`}
          />
          <span
            className={`h-[2px] w-6 bg-black transition duration-300 ${
              menuOpen ? 'opacity-0' : ''
            }`}
          />
          <span
            className={`h-[2px] w-6 bg-black transition duration-300 ${
              menuOpen ? '-translate-y-[7px] -rotate-45' : ''
            }`}
          />
        </button>
      </nav>
    </>
  )
}
