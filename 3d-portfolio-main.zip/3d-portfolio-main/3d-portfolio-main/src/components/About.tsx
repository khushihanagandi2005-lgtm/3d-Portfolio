import { profile } from '../data/portfolio'
import { useInView } from '../hooks/useInView'

export function About() {
  const { ref, inView } = useInView<HTMLElement>()

  return (
    <section
      id="about"
      ref={ref}
      className={`relative z-[3] px-5 py-24 sm:px-8 md:px-10 md:py-32 ${
        inView ? 'reveal is-visible' : 'reveal'
      }`}
    >
      <div className="glass-panel mx-auto max-w-3xl rounded-3xl px-6 py-10 sm:px-10 sm:py-12">
        <p className="mb-3 text-[12px] tracking-[0.14em] text-black/55 uppercase sm:text-[13px]">
          About
        </p>

        <div className="mb-5 flex items-start justify-between gap-4 sm:gap-6">
          <h2
            className="min-w-0 flex-1 text-[32px] leading-tight text-black sm:text-[42px]"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            {profile.role}
          </h2>
          <img
            src="/Khushi.jpeg"
            alt={profile.name}
            width={112}
            height={112}
            className="h-20 w-20 shrink-0 rounded-full object-cover object-top ring-2 ring-white/70 shadow-[0_6px_20px_rgba(0,30,60,0.18)] sm:h-28 sm:w-28"
          />
        </div>

        <div className="mb-7 flex max-w-2xl flex-col gap-4">
          {profile.bio.map((paragraph) => (
            <p
              key={paragraph.slice(0, 32)}
              className="text-[14px] leading-relaxed text-black sm:text-[15px]"
            >
              {paragraph}
            </p>
          ))}
        </div>
        <p
          className="mb-6 text-[15px] text-black/80 italic sm:text-[16px]"
          style={{ fontFamily: 'var(--font-heading)' }}
        >
          {profile.tagline}
        </p>
        <div className="flex flex-wrap gap-x-8 gap-y-2 text-[13px] text-black/80 sm:text-[14px]">
          <span>{profile.focus}</span>
          <span>{profile.location}</span>
        </div>
      </div>
    </section>
  )
}
