/** Solid black laptop mark — no emoji */
export function LaptopLogo({ className = '' }: { className?: string }) {
  return (
    <svg
      className={className}
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="#000000"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect x="3" y="3.5" width="18" height="11.5" rx="1.5" />
      <path d="M1 17h22v1.75c0 .69-.56 1.25-1.25 1.25H2.25C1.56 20 1 19.44 1 18.75V17z" />
    </svg>
  )
}
